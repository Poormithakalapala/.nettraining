﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCassessment2.Models
{
    public class Movie
    {
        public int Mid { get; set; }             
        public string MovieName { get; set; }    
        public DateTime DateOfRelease { get; set; }  
    }
}
